# -*-coding:utf-8 -*-
"""
@project: ${PROJECT_NAME}
@author: ${USER}
@file: ${NAME}.py
@time: ${YEAR}-${MONTH}-${DAY} ${HOUR}:${MINUTE}:${SECOND}
# code is far away from bugs with the god animal protecting
    I love animals. They taste delicious.
              ┏┓      ┏┓
            ┏┛┻━━━┛┻┓
            ┃      ☃      ┃
            ┃  ┳┛  ┗┳  ┃
            ┃      ┻      ┃
            ┗━┓      ┏━┛
                ┃      ┗━━━┓
                ┃  神兽保佑    ┣┓
                ┃　永无BUG。   ┏┛
                ┗┓┓┏━┳┓┏┛
                  ┃┫┫  ┃┫┫
                  ┗┻┛  ┗┻┛
"""